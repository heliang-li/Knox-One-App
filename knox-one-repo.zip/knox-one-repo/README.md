# Knox One

The pitch draft of Knox One, a basketball platform for the Knox Grammar 1sts and 2nds.

The whole app is in `index.html`. It works on phones and laptops, and nobody needs to sign in.

It comes loaded with a made-up example season. Each visitor gets their own copy of the example data, saved in their own browser, so visitors can't change anyone else's.

## Deploy on Render

1. On Render, go to New → Static Site and pick this repository.
2. Leave the build command empty and set the publish directory to `.`.
3. Click Create Static Site.

Or use New → Blueprint, which reads the settings from `render.yaml`.

## Updating

Replace `index.html` with a newly built copy and commit it. Render redeploys on its own.
